<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Apis\Admin\ChannelController;
use App\Http\Controllers\Apis\Admin\TeacherController;

Route::prefix("admin")->group(function () {
    Route::apiResource('channels', ChannelController::class);
    Route::apiResource('teachers', TeacherController::class);
});
