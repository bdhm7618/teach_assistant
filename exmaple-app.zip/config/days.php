<?php

return [

        "saturday"  => "السبت",
        "sunday"    => "الأحد",
        "monday"    => "الاثنين",
        "tuesday"   => "الثلاثاء",
        "wednesday" => "الأربعاء",
        "thursday"  => "الخميس",
        "friday"    => "الجمعة",

    
];
