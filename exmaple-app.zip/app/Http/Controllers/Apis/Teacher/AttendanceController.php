<?php

namespace App\Http\Controllers\Apis\Teacher;

use App\Models\Group;
use App\Models\ClassTime;
use App\Models\Attendance;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Admin\AttendanceRequest;
use App\Http\Resources\Attendance\AttendanceResource;
use App\Http\Resources\Attendance\GroupResource;

class AttendanceController extends Controller
{
    public function getGroups()
    {


        $results = ClassTime::with([
            'group.students' => function ($q) {
                $q->select('id', 'name', 'email', 'group_id');
            }
        ])
            ->whereHas('group', function ($q) {
                $q->where('channel_id', $this->channel->id);
            })
            ->where('day_name', DB::raw('DAYNAME(CURDATE())'))
            ->get();


        return successResponse(GroupResource::collection($results));
    }
    public function index()
    {
        try {
            $attendance = Attendance::all();
            return successResponse(AttendanceResource::collection($attendance));
        } catch (\Exception $e) {
            return errorResponse("error", $e);
        }
    }

    public function show($id)
    {
        try {
            $record = Attendance::findOrFail($id);
            return successResponse(new AttendanceResource($record));
        } catch (\Exception $e) {
            return errorResponse("error", $e);
        }
    }

    public function store(AttendanceRequest $request)
    {
        DB::beginTransaction();
        try {
            $record = Attendance::create($request->validated());
            DB::commit();
            return successResponse(new AttendanceResource($record));
        } catch (\Exception $e) {
            DB::rollBack();
            return errorResponse("error", $e);
        }
    }

    public function update(AttendanceRequest $request, $id)
    {
        DB::beginTransaction();
        try {
            $record = Attendance::findOrFail($id);
            $record->update($request->validated());
            DB::commit();
            return successResponse(new AttendanceResource($record));
        } catch (\Exception $e) {
            DB::rollBack();
            return errorResponse("error", $e);
        }
    }

    public function destroy($id)
    {
        DB::beginTransaction();
        try {
            $record = Attendance::findOrFail($id);
            $record->delete();
            DB::commit();
            return successResponse("Attendance deleted successfully");
        } catch (\Exception $e) {
            DB::rollBack();
            return errorResponse("error", $e);
        }
    }
}
