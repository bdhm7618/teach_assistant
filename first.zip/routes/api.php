<?php

require __DIR__ . "/core/api-v1.php";
