<?php

namespace App\Rules;

use App\Models\Attendance;
use App\Models\SessionTime;
use Closure;
use App\Models\Student;
use Illuminate\Contracts\Validation\ValidationRule;

class StudentIdsRule implements ValidationRule
{
    public function __construct(private $session_time_id) {}
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string, ?string=): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        $ids = array_filter(array_map('trim', explode(',', $value)));

        if (empty($ids)) {
            $fail("The $attribute field must contain at least one ID.");
            return;
        }

        if (count($ids) !== count(array_unique($ids))) {
            $fail("The $attribute field contains duplicate IDs.");
            return;
        }

        $group_id = SessionTime::find($this->session_time_id)?->group_id;


        foreach ($ids as $id) {
            if (!ctype_digit($id)) {
                $fail("The $attribute field must contain only numeric IDs.");
                return;
            }

            $student = Student::find($id);

            if ($student?->group_id != $group_id) {
                $fail("This student ID [{$student?->id}] is not a member of the specified group number [$group_id].");
                return;
            }

            if (Attendance::where([
                ["session_time_id", "=", $this->session_time_id],
                ["student_id", "=", $id],
                ["date", "=", date("Y-m-d")]
            ])->exists()) {
                $fail("This student with ID $id is already assigned to the selected session time today.");
                return;
            }
        }


        $count = Student::whereIn('id', $ids)->count();

        if ($count !== count($ids)) {
            $fail("Some student IDs do not exist in the database.");
        }
    }
}
