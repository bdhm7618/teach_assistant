<?php

namespace App\Http\Controllers;

abstract class Controller
{
    protected $teacher;
    protected $channel;
    protected $admin;
    public function __construct()
    {
        $this->teacher = auth("teacher")?->user();
        $this->admin = auth("admin")?->user();
        $this->channel = $this->teacher?->channel;
    }
}
